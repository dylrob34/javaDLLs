package logger;

import javafx.application.Platform;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Logger {


    public static main.MainController mainCtlr;

    public static String path;

    public static File logFile;

    static {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyy-MM-dd HH-mm-SS");
        path = "C:/GENETiCS/logs/" + dtf.format(LocalDateTime.now()) + ".txt";
        try {
            logFile = new File(path);
            logFile.createNewFile();
        } catch (IOException ex)
        {
            log("Error creating log file");
        }
    }

    public static void log(String s) {
        Platform.runLater(new Runnable() {
            public void run() {
                mainCtlr.log(s);
            }
        });
        try {
            FileWriter out = new FileWriter(path, true);
            out.write(s + "\n");
            out.close();
        } catch (IOException ex) {
        }
    }

}
