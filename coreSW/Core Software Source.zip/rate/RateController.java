package rate;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.Duration;
import main.DeviceControl;

public class RateController {

    @FXML
    Label axisOnePosLabel;
    @FXML
    Label axisOneRateLabel;
    @FXML
    Label axisTwoPosLabel;
    @FXML
    Label axisTwoRateLabel;


    @FXML
    TextField axisOnePosField;
    @FXML
    TextField axisOneRateField;
    @FXML
    TextField axisTwoPosField;
    @FXML
    TextField axisTwoRateField;

    @FXML
    SplitPane topContainer;

    String onePos;
    String oneRate;
    String twoPos;
    String twoRate;

    Timeline update;

    public void initialize() {
        topContainer.lookupAll(".split-pane-divider").stream().forEach(div -> div.setMouseTransparent(true));

        this.update = new Timeline(new KeyFrame(Duration.seconds(1), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                onePos = main.DeviceControl.getAxisOnePos();
                oneRate = main.DeviceControl.getAxisOneRate();
                twoPos = main.DeviceControl.getAxisTwoPos();
                twoRate = main.DeviceControl.getAxisTwoRate();

                axisOnePosLabel.setText(onePos);
                axisOneRateLabel.setText(oneRate);
                axisTwoPosLabel.setText(twoPos);
                axisTwoRateLabel.setText(twoRate);
            }
        }));

        this.update.setCycleCount(Timeline.INDEFINITE);
        this.update.play();
    }

    public void stopUpdate() {
        this.update.stop();
    }

    public void sendAxisOnePos() {
        main.DeviceControl.sendAxisOnePos(axisOnePosField.getText());
        axisOnePosLabel.setText(main.DeviceControl.getAxisOnePos());
    }

    public void sendAxisOneRate() {
        main.DeviceControl.sendAxisOneRate(axisOneRateField.getText());
    }

    public void sendAxisTwoPos() {
        main.DeviceControl.sendAxisTwoPos(axisTwoPosField.getText());
    }

    public void sendAxisTwoRate() {
        main.DeviceControl.sendAxisTwoRate(axisTwoRateField.getText());
    }

}
