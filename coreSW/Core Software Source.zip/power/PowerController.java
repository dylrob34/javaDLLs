package power;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import logger.Logger;

public class PowerController {


    @FXML
    Button setVoltButton;
    @FXML
    ToggleButton powerToggle;
    @FXML
    TextField voltageInput;

    public void initialize() {
        voltageInput.setText(main.DeviceControl.getVoltage());
        boolean selected = (main.DeviceControl.getStatus().equals("1")) ? true : false;
        powerToggle.setSelected(selected);
        if (selected)
            powerToggle.setStyle("-fx-base: green;");
        else
            powerToggle.setStyle("-fx-base: red;");
    }

    public void togglePower() {
        if (powerToggle.isSelected()) {
            logger.Logger.log("Applying Power");
            main.DeviceControl.powerOn();
            powerToggle.setStyle("-fx-base: green;");
        } else {
            logger.Logger.log("Removing Power");
            main.DeviceControl.powerOff();
            powerToggle.setStyle("-fx-base: red;");
        }
    }

    public void setVoltage() {
        String voltage = voltageInput.getText();
        logger.Logger.log("Setting Voltage to " + voltage + " volts");
        main.DeviceControl.setVoltage(voltage);
    }
}
