package temperature;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.Duration;

public class TemperatureController {

    @FXML
    Label pvLabel;
    @FXML
    Label spLabel;

    @FXML
    TextField spTextField;

    String pv;
    String sp;

    Timeline update;

    public void initialize() {
        this.update = new Timeline(new KeyFrame(Duration.seconds(1), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                pv = main.DeviceControl.getPV();
                sp = main.DeviceControl.getSP();

                pvLabel.setText(pv);
                spLabel.setText(sp);
            }
        }));

        this.update.setCycleCount(Timeline.INDEFINITE);
        this.update.play();
    }

    public void stopUpdate() {
        this.update.stop();
    }

    public void sendSetpoint() {
        main.DeviceControl.sendManualSP(spTextField.getText()); ;
    }

    public void stopUpdating()
    {
        main.DeviceControl.stopUpdatingTemperature();
    }

}
