package main;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import main.uutData.*;
import rate.RateController;
import temperature.TemperatureController;

import java.io.*;

public class MainController {

    @FXML  TableView dataTable;
    @FXML  TableColumn wordColumn;
    @FXML  TableColumn unitColumn;
    @FXML  TableColumn valueColumn;
    @FXML  TreeView fileTree;

    @FXML
    TextArea logTextArea;

    @FXML
    ListView testList;

    @FXML
    TextField fileNameInput;
    @FXML
    TextField samplesInput;

    @FXML
    Label samplesCollectedLabel;
    @FXML
    Label sampleRateLabel;

    private Stage powerWindow;
    private Stage rateWindow;
    private Stage tempWindow;
    private UUTTable table;

    private boolean uutUpdateThread;

    @FXML
    TextField opField;
    @FXML
    TextField uutField;
    @FXML
    TextField locationField;
    @FXML
    TextField comField;
    @FXML
    TextField loopsField;

    private Settings settings;

    public void initialize() {
        System.loadLibrary("comPortDetector");
        table = new UUTTable();
        wordColumn.setCellValueFactory(new PropertyValueFactory<Word, String>("word"));
        valueColumn.setCellValueFactory(new PropertyValueFactory<Word, String>("value"));
        unitColumn.setCellValueFactory(new PropertyValueFactory<Word, String>("unit"));

        dataTable.setFixedCellSize(25);
        dataTable.prefHeightProperty().bind(dataTable.fixedCellSizeProperty().multiply(Bindings.size(dataTable.getItems()).add(1.25)));
        dataTable.minHeightProperty().bind(dataTable.prefHeightProperty());
        dataTable.maxHeightProperty().bind(dataTable.prefHeightProperty());

        dataTable.getItems().addAll(table.getWords());

        generateTree();
        settings = null;
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("settings.gen"));
            settings = (Settings)in.readObject();
            in.close();
        } catch (ClassNotFoundException ex) {
            settings = new Settings();
        } catch (IOException ex) {
            settings = new Settings();
        }

        opField.setText(settings.getOperator());
        uutField.setText(settings.getUut());
        locationField.setText(settings.getLocation());
        comField.setText(settings.getComPort());

        apply();

        samplesInput.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (!newValue.matches("\\d")) {
                    samplesInput.setText(newValue.replaceAll("[^\\d]", ""));
                }
            }
        });

        loopsField.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (!newValue.matches("\\d")) {
                    loopsField.setText(newValue.replaceAll("[^\\d]", ""));
                }
            }
        });


        Thread t = new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        updateUUTInfo();
                    }
                }
        );
        uutUpdateThread = true;
        t.start();
    }

    public void launchPower() {
        if (this.powerWindow == null) {
            this.powerWindow = new Stage();
            Parent root;
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/power/powerController.fxml"));
                root = loader.load();
            } catch (IOException ex) {
                System.err.println("Error: Could not load powerController.fxml");
                ex.printStackTrace();
                return;
            }
            this.powerWindow.setTitle("Power Control");
            this.powerWindow.setScene(new Scene(root, 331, 112));
            this.powerWindow.getScene().getStylesheets().add("/assets/dark-theme.css");
            this.powerWindow.setOnCloseRequest((WindowEvent event) -> { this.powerWindow = null; });


            this.powerWindow.show();
        } else {
            this.powerWindow.requestFocus();
        }
    }

    public void launchRate() {
        if (this.rateWindow == null) {
            this.rateWindow = new Stage();
            Parent root;
            RateController ctlr;
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/rate/rateController.fxml"));
                root = loader.load();
                ctlr = loader.getController();
            } catch (IOException ex) {
                System.err.println("Error: Could not load rateController.fxml");
                ex.printStackTrace();
                return;
            }
            this.rateWindow.setTitle("Rate Control");
            this.rateWindow.setScene(new Scene(root, 602, 295));
            this.rateWindow.getScene().getStylesheets().add("/assets/dark-theme.css");
            this.rateWindow.setOnCloseRequest((WindowEvent event) -> {
                ctlr.stopUpdate();
                this.rateWindow = null;
            });


            this.rateWindow.show();
        } else {
            this.rateWindow.requestFocus();
        }
    }

    public void launchTemperature() {
        if (this.tempWindow == null) {
            this.tempWindow = new Stage();
            Parent root;
            TemperatureController ctlr;
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/temperature/temperatureController.fxml"));
                root = loader.load();
                ctlr = loader.getController();
            } catch (IOException ex) {
                System.err.println("Error: Could not load temperature/Controller.fxml");
                ex.printStackTrace();
                return;
            }
            this.tempWindow.setTitle("Temperature Control");
            this.tempWindow.setScene(new Scene(root, 382, 238));
            this.tempWindow.getScene().getStylesheets().add("/assets/dark-theme.css");
            this.tempWindow.setOnCloseRequest((WindowEvent event) -> {
                ctlr.stopUpdate();
                this.tempWindow = null;
            });


            this.tempWindow.show();
        } else {
            this.tempWindow.requestFocus();
        }
    }

    public void generateTree() {
        // Build file tree
        TreeItem root = new TreeItem<>();
        root.setExpanded(true);
        makeBranch("C:/dev/GENETiCS/External/SourceFiles", root);
        fileTree.setRoot(root);
        fileTree.setShowRoot(false);
    }

    public void makeBranch(String path, TreeItem root) {
        File dir = new File(path);
        File[] contents = dir.listFiles();
        if (contents != null) {
            for (File file : contents) {
                if (file.isFile()) {
                    root.getChildren().add(new TreeItem<Leaf>(new Leaf(file.getAbsolutePath(), file.getName(), false)));
                } else if (file.isDirectory()) {
                    String newPath = file.getAbsolutePath();
                    String name = file.getName();
                    TreeItem<Leaf> parent = new TreeItem<Leaf>(new Leaf(newPath, name, true));
                    root.getChildren().add(parent);
                    makeBranch(newPath, parent);
                }
            }
        }
    }

    public void log(String s) {
        this.logTextArea.appendText(s + "\n");
    }

    public void stopUpdateUUTInfo() {
        uutUpdateThread = false;
    }

    public void updateUUTInfo() {
        long startTime = System.nanoTime();

        while (uutUpdateThread)
        {
            if (System.nanoTime() - startTime > 1000000000) {
                String[] data = DeviceControl.getUUTData();
                table.updateWords(data);
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        dataTable.getItems().removeAll(dataTable.getItems());
                        dataTable.getItems().addAll(table.getWords());
                        samplesCollectedLabel.setText(data[9]);
                        sampleRateLabel.setText(data[10]);
                    }
                });

                startTime = System.nanoTime();
            }

        }
    }

    public void addTest() {
        TreeItem<Leaf> item = (TreeItem<Leaf>)this.fileTree.getSelectionModel().getSelectedItem();
        if (item != null)
            if (!item.getValue().isDir())
                this.testList.getItems().add(item.getValue());
    }

    public void removeTest() {
        Leaf item = (Leaf)this.testList.getSelectionModel().getSelectedItem();
        if (item != null)
            this.testList.getItems().remove(item);
    }

    public void executeTest() {
        ObservableList<Leaf> items = this.testList.getItems();
        String[] tests = new String[items.size()];
        String loopString = this.loopsField.getText();
        for (int i = 0; i < items.size(); i++) {
            tests[i] = items.get(i).getPath();
        }
        if (!loopString.equals(""))
        {
            int loops = Integer.parseInt(loopString);
            main.DeviceControl.execute(opField.getText(), uutField.getText(), locationField.getText(), tests, loops);
        }
        else {
            main.DeviceControl.execute(opField.getText(), uutField.getText(), locationField.getText(), tests, 1);
        }

    }

    public void record() {
        String fName = this.fileNameInput.getText();
        String samplesString = this.samplesInput.getText();
        if (!samplesString.equals(""))
        {
            int samples = Integer.parseInt(samplesString);
            main.DeviceControl.record(fName, samples);
        }
        String[] port = getComPorts();
        for (String s : port) {
            System.out.println(s);
        }
    }

    public void verifyTest() {
        ObservableList<Leaf> items = this.testList.getItems();
        String[] tests = new String[items.size()];
        String loops = this.loopsField.getText();
        for (int i = 0; i < items.size(); i++) {
            tests[i] = items.get(i).getPath();
        }
        if (!loops.equals(""))
        {
            int loop = Integer.parseInt(loops);
            main.DeviceControl.verify(tests, loop);
        }
        else {
            main.DeviceControl.verify(tests, 1);
        }
    }

    public void abortTest() {
        main.DeviceControl.abortTest();
    }

    public void apply() {
        DeviceControl.sendComPort(comField.getText());
    }

    public void onExit() {
        stopUpdateUUTInfo();
        try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("settings.gen"));
            out.writeObject(settings);
            out.close();
        } catch (IOException ex){

        }
    }

    public void onOperator() {
        settings.setOperator(opField.getText());
    }

    public void onUUT() {
        settings.setUut(uutField.getText());
    }

    public void onLocation() {
        settings.setLocation(locationField.getText());
    }

    public void onCOM() {
        settings.setComPort(comField.getText());
    }

    public native String[] getComPorts();

    public void clearLog()
    {
        this.logTextArea.setText("");
    }

}
