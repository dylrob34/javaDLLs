package main;

public class DeviceControl {

    static {
        System.loadLibrary("GENETiCS");
        load();
    }

    // Init functions
    static private native void load();

    // IMU functions

    static public native String[] getUUTData();

    static public native void sendComPort(String port);

    // Power Supply functions

    static public native void powerOn();

    static public native void powerOff();

    static public native void setVoltage(String voltage);

    static public native String getVoltage();

    static public native String getStatus();

    // Rate Table functions

    static public native void sendAxisOnePos(String position);

    static public native void sendAxisOneRate(String rate);

    static public native void sendAxisTwoPos(String position);

    static public native void sendAxisTwoRate(String rate);

    static public native String getAxisOnePos();

    static public native String getAxisOneRate();

    static public native String getAxisTwoPos();

    static public native String getAxisTwoRate();

    // Test script functions

    static public native void execute(String name, String UUT, String location, String[] tests, int loops);

    static public native void verify(String[] tests, int loops);

    static public native void abortTest();

    // manual recording

    static public native void record(String fileName, int samples);

    // Temp Controller functions

    static public native String getPV();

    static public native String getSP();

    static public native void sendManualSP(String setpoint);

    static public native void stopUpdatingTemperature();

}
