package main;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logger.Logger;

public class Main extends Application{

    @Override
    public void start(Stage primaryStage) throws Exception{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("main.fxml"));
        Parent root = loader.load();
        MainController mainCtlr = loader.getController();
        Logger.mainCtlr = mainCtlr;
        primaryStage.setTitle("MK-48 Core Software");
        primaryStage.setScene(new Scene(root, 1002, 673));
        primaryStage.setOnCloseRequest((WindowEvent event) -> {Platform.exit(); mainCtlr.onExit(); });
        primaryStage.getScene().getStylesheets().add("/assets/dark-theme.css");
        primaryStage.show();
    }


    public static void main(String[] args) {


        launch(args);
    }
}
