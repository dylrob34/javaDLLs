package main;

import java.io.Serializable;

public class Settings implements Serializable {
    private String operator;
    private String uut;
    private String location;
    private String comPort;

    public Settings() {
        this.operator = "";
        this.uut = "";
        this.location = "";
        this.comPort = "";
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getUut() {
        return uut;
    }

    public void setUut(String uut) {
        this.uut = uut;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getComPort() {
        return comPort;
    }

    public void setComPort(String comPort) {
        this.comPort = comPort;
    }
}
