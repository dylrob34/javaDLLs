package main;

public class Leaf {

    private String path;
    private String name;
    private boolean dir;

    public Leaf(String path, String name, boolean dir) {
        this.path = path;
        this.name = name;
        this.dir = dir;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public boolean isDir() {
        return this.dir;
    }

    @Override
    public String toString() {
        return this.name;
    }

}
