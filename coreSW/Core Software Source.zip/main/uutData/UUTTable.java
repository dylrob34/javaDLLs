package main.uutData;

import main.DeviceControl;

public class UUTTable {

    private Word[] words;

    public UUTTable() {
        this.words = new Word[9];

        words[0] = new Word("rYaw", "radians");
        words[1] = new Word("yaw", "radians");
        words[2] = new Word("pitch", "radians");
        words[3] = new Word("roll", "radians");
        words[4] = new Word("dvx", "m/s");
        words[5] = new Word("dvy", "m/s");
        words[6] = new Word("dvz", "m/s");
        words[7] = new Word("BIST", "hex");
        words[8] = new Word("checksum", "hex");

    }

    public void updateWords(String[] data) {
        for (int i = 0; i < words.length; i++) {
            words[i].setValue(data[i]);
        }
    }

    public Word[] getWords() {
        return this.words;
    }
}
