package main.uutData;

public class Word {

    private String word;
    private String unit;
    private String value;

    public Word(String word, String unit) {
        this.word = word;
        this.unit = unit;
        this.value = "na";
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
